//
//  AppDelegate.h
//  VideoTestingGPUImage
//
//  Created by Jake Gundersen on 10/2/12.
//  Copyright (c) 2012 Jake Gundersen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
