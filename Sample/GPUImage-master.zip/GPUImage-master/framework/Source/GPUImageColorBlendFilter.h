#import "GPUImageTwoInputFilter.h"

@interface GPUImageColorBlendFilter : GPUImageTwoInputFilter

@end
