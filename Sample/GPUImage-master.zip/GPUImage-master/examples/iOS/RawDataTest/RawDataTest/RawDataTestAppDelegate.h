#import "GPUImage.h"
#import <UIKit/UIKit.h>

@interface RawDataTestAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
