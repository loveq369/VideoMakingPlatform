img-to-video
============

Convert a series of images to video with audio