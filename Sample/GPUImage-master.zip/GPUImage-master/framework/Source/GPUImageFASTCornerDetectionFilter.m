#import "GPUImageFASTCornerDetectionFilter.h"

@implementation GPUImageFASTCornerDetectionFilter

@end
