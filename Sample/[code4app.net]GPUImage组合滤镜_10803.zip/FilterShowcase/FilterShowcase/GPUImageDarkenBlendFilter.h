#import "GPUImageTwoInputFilter.h"

@interface GPUImageDarkenBlendFilter : GPUImageTwoInputFilter
{
}

@end
